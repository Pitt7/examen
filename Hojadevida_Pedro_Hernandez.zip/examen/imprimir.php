#!/usr/bin/perl

### SAI SSL
### Ultima revision : 23/04/2016 - Se agrega botón para accesar Video
#

use CGI qw /:standard :html3/;
use CGI::Carp qw(fatalsToBrowser);
$query = new CGI;
print "Content-type:text/html\n\n";

################################
###  AREA DE CONFIGURACION   ###
################################

### Definicion de Variables
#

$cgiurl  = "imprimir_propiedad.cgi";

### Datos de Configuracion Oficina

require "../librerias/funciones_db.pl";
$id_oficina    = $query->param('id_oficina');
@oficina = &ObtenerOficinaById($id_oficina);
$fotosurl    = "$oficina[2]/fotos";
### Bootstrap
#
$bootstrap ="$oficina[1]/bootstrap335";
$imgurl    = "$bootstrap/img";

### Bases de Datos

#####################
### Formato de Pagina
#

$font_1  = "<FONT FACE=\"arial\" SIZE=-1>";
$font_2  = "<FONT FACE=\"arial\" SIZE=-2>";
$textc   = "#000000";
$linkc   = "#0000FF";
$alinkc  = "#0000FF";
$vlinkc  = "#0000FF";
$bgc     = "#FFFFFF";
$bkg     = "";

###################################################
###           TERMINA CONFIGURACION             ###
###   NO MODIFICAR NADA DESPUES DE ESTA LINEA   ###
###################################################

$id            = $query->param('id');
$id_usuario    = $query->param('id_usuario');
$nivel         = $query->param('nivel');
$ref_propiedad = $query->param('ref_propiedad');
$ref_asesor    = $query->param('ref_asesor');
$propiedades   = $query->param('propiedades');
$web           = $query->param('web');
$solicitud     = $query->param('solicitud');
$mapa = $query->param('mapa');
$d_latitud = $query->param('latitud');
$d_longitud = $query->param('longitud');
### Librerias
#
require "../librerias/fechas.pl";
require "../librerias/formato_precios.pl";
# propias
require "librerias/header.pl";


### Inicio de Programa
#

&Fechas;
&Presentar_Forma_Impresion;

sub Presentar_Forma_Impresion {

print <<END_OF_TEXT;
<!DOCTYPE html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    
    <TITLE>Propiedad ID : $id</TITLE>

    <!-- Bootstrap -->
    <link href="$bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    
    <![endif]-->
END_OF_TEXT
if ($mapa == 1) {
print <<END_OF_TEXT;
    <style>
        #map-canvas {
        width: 400px;
        height: 330px;
        background-color: #CCC;
      }
    </style>
  
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkTU8Zp0nIJMyZdOXprXsXk9ZBDPL3s4I"></script>
    
    <script>
    
    function initialize() {
    var myLatlng = new google.maps.LatLng($d_latitud, $d_longitud);
    var mapOptions = {
    zoom: 14,
    center: myLatlng
    }
    var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

    var marker = new google.maps.Marker({
      position: myLatlng,
      map: map,
      title: 'Propiedad ID : $id'
  });
  
  }

  google.maps.event.addDomListener(window, 'load', initialize);
  </script>


END_OF_TEXT
}  

print <<END_OF_TEXT;
<SCRIPT LANGUAGE="JavaScript">
function makeNewWindow(newURL)
{ var newwindow=window.open(newURL,"", "resizable,scrollbars=yes,height=500,width=1000,top=60,left=120")}
</SCRIPT>
<BODY>
<!-- Inicia Tabla de Header -->
<!-- <br>
<TABLE WIDTH="650" CELLSPACING="0" CELLPADDING="0" BORDER="1" BGCOLOR="#FFFFFF">
<tr >
    <th colspan="2"><div>
    <img src="$bootstrap/img/header.jpg" style="width:71%; margin-left:205px"></div> </th>
    <th bgcolor="#FF0000"><br><center><p style="margin: -60px -329px -35px;">$oficina[7]
                $oficina[20], $oficina[24], <br>$oficina[26], $oficina[23].<BR>
                Tel.$oficina[10] &nbsp;</p></center></th><br><br>
  </tr>
<TR>
    <td>
<div class="container">

    <div class="row" >-->
        <!--<div class="container-fluid col-md-12" style="background-image:url('$bootstrap/img/header.jpg'); ">
            <img src="$bootstrap/img/header.jpg" style="padding-left: 1px;" width="900"  >
            
            
         </div>-->
    <!--</div>
</div></td></TR>
</TABLE>-->
<!-- Termina Tabla de Header -->
<center>
<TABLE WIDTH="900" CELLSPACING="0" CELLPADDING="0" BORDER="1" BGCOLOR="#FFFFFF" style="margin-top: -59px;">
<tr >

    <td colspan="3"><div>
    <img src="$bootstrap/img/header.jpg" style="width: 100%;
    margin-left: -0px;"></div> </td>
    <td ><p style="margin: -34px -348px -23px; text-align:left;">$oficina[7]<br>
                $oficina[20], $oficina[24], $oficina[26], $oficina[23].<BR>
                Tel.$oficina[10] &nbsp;</p></td><br><br>
  </tr>
 
<TR> <br>
END_OF_TEXT

if ($propiedades eq "2" && $solicitud eq "Interna") {
print " \&nbsp; \&nbsp; \&nbsp; <B>Solicitamos información adicional de la sig. propiedad :</B><BR><BR>\n";
}

print <<END_OF_TEXT;

<TD HEIGHT="920" ALIGN="center" VALIGN="top">
$font_1

END_OF_TEXT

if ($propiedades eq "2" || $web eq "1") {
@data = &Bolsa($oficina[16]);
}
else {
# open(DATA,"$archivo");
# @data = <DATA>;
# close(DATA);
@data = &PropiedadesList($oficina[5]);
}

for (my $i = 0; $i < scalar @data; $i++) {
if ($ref_propiedad ne "") {$busqueda = $ref_propiedad eq $data[$i]{id_propiedad};} else {$busqueda = $id eq $data[$i]{ref_propiedad};}
if ($busqueda) {
$oficina_propiedad = "$data[$i]{id_oficina}";
$col_propiedad = "$data[$i]{colonia}";
#
if (($propiedades eq "2" || $propiedades eq "1") && $nivel ne "4") {@asesores = &AsesoresRed($oficina[16]);}
else {
@asesores = &AsesoresList($oficina[5]);
@usuarios = &UsuariosList($oficina[5]);
push (@asesores,@usuarios);
}
if ($web eq "1" && $propiedades ne "2" && $propiedades ne "0") {$id_usuario = $data[$i]{id_asesor};}
if ($propiedades eq "2" && $solicitud eq "Interna") {$id_usuario = "$data[$i]{id_asesor}";}
if ($nivel eq "4") {$id_usuario = $ref_asesor;}

for (my $i = 0; $i < scalar @asesores; $i++) {
if ($id_usuario eq "$asesores[$i]{id_asesor}" || $id_usuario eq "$asesores[$i]{id_usuario}") {
$nombre_asesor = "$asesores[$i]{nombre} $asesores[$i]{apellido_pat} $asesores[$i]{apellido_mat}";
if ($asesores[$i]{celular} ne "" && $web ne "1") {
$tel_asesor = "Tel. : $asesores[$i]{tel_of}\&nbsp; Celular : $asesores[$i]{celular} \&nbsp; Fax. : $asesores[$i]{fax}<BR>Email : $asesores[$i]{email}";
}
else {
$tel_asesor = "Tel. : $asesores[$i]{tel_of} \&nbsp; \&nbsp; Fax. : $asesores[$i]{fax}<BR>Email : $asesores[$i]{email}";
}

} 
}
#

if ($propiedades eq "2" || $web eq "1") {
@oficina_red_array= &ObtenerOficinaById($oficina_propiedad);
$oficina_red = $oficina_red_array[27];
$fotosurl    = "$oficina_red_array[2]/fotos";
}

print <<END_OF_TEXT;
<TABLE WIDTH="600" CELLSPACING="5" CELLPADDING="0" BORDER="0">
<TR><TD COLSPAN="2" VALIGN="top" ALIGN="center">

<TABLE WIDTH="600" CELLSPACING="0" CELLPADDING="0" BORDER="0">
<TR><TD>
$font_1
<B style="margin-left: -137px;">Propiedad ID : $data[$i]{ref_propiedad}</B><BR>
<B style="margin-left: -137px;">Tipo :</B> $data[$i]{inmueble} &nbsp;&nbsp; <B>Zona :</B> $data[$i]{zona} &nbsp;&nbsp; <B>Operación :</B> $data[$i]{operacion}</TD>
<TD ALIGN="right">
<form>
<input type="button" class="btn tbn-primary"
value="Imprimir Página!"
onClick="javascript:print()">
</form>
</TD></TR>
</TABLE>

</TD></TR>
<TR>
    <TD WIDTH="350" ALIGN="center">
        <IMG SRC="$fotosurl/$data[$i]{foto1}" WIDTH="513" BORDER="0" style="margin: 3px 3px -8px -136px;"><BR>
        <IMG SRC="$imgurl/blank.gif" WIDTH="120" HEIGHT="5" BORDER="0" style="    margin: 3px 3px -8px -136px;"><BR>
END_OF_TEXT

print <<END_OF_TEXT;
</TD>
<TD WIDTH="250">
$font_1
 &nbsp; &nbsp; &nbsp; &nbsp; Terreno : $data[$i]{areat} mts2.<BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Construcción $data[$i]{areac} mts2.<BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Frente : $data[$i]{frente} mts<BR>

 <BR>
END_OF_TEXT
#################################################
#casas,departamentos,amueblados,quintas
if ($data[$i]{id_tipo}  eq "1" || $data[$i]{id_tipo}  eq "2" || $data[$i]{id_tipo}  eq "3" || $data[$i]{id_tipo}  eq "9") {
print <<END_OF_TEXT;
 &nbsp; &nbsp; &nbsp; &nbsp; Plantas : $data[$i]{plantas} <BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Recámaras : $data[$i]{rec} <BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Baños : $data[$i]{banos} <BR>
END_OF_TEXT
}
#dificios
if ($data[$i]{id_tipo} eq "4") {
print <<END_OF_TEXT;
 &nbsp; &nbsp; &nbsp; &nbsp; Uso : $data[$i]{uso} <BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Pisos : $data[$i]{plantas} <BR>
END_OF_TEXT
}
#terrenos
if ($data[$i]{id_tipo}  eq "5") {
print <<END_OF_TEXT;
 &nbsp; &nbsp; &nbsp; &nbsp; Uso : $data[$i]{uso} <BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Estado : $data[$i]{estado_prop} <BR>
END_OF_TEXT
}
#oicinas, locales,bodegas
if ($data[$i]{id_tipo}  eq "6" || $data[$i]{id_tipo}  eq "7" || $data[$i]{id_tipo}  eq "8") {
print <<END_OF_TEXT;
 &nbsp; &nbsp; &nbsp; &nbsp; Area Oficina : $data[$i]{area_of}  mts2<BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Area Bodega : $data[$i]{area_bod}  mts2<BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Area Maniobras : $data[$i]{area_man}  mts2<BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Baños : $data[$i]{banos1} <BR>
END_OF_TEXT
}
#ranchos
if ($data[$i]{id_tipo}  eq "10") {
print <<END_OF_TEXT;
 &nbsp; &nbsp; &nbsp; &nbsp; Uso : $data[$i]{usos} <BR>
 &nbsp; &nbsp; &nbsp; &nbsp; Servicios : $data[$i]{serv} <BR>
END_OF_TEXT
}

&Formato_Precio($data[$i]{precio_max});

print <<END_OF_TEXT;
<BR>
<CENTER><B>Precio de $data[$i]{operacion} </B><BR>$formato_precio $data[$i]{moneda} </CENTER>

</TD></TR>
<tr>
    <td>
END_OF_TEXT
if ($data[$i]{foto2} ne "") {
    print"   <IMG SRC=\"$fotosurl/$data[$i]{foto2}\" WIDTH=\"166\"  BORDER=\"0\" style=\"margin: 0px 0px 1px -135px;\">&nbsp;
        <IMG SRC=\"$fotosurl/$data[$i]{foto3}\" WIDTH=\"166\"  BORDER=\"0\">&nbsp;
        <IMG SRC=\"$fotosurl/$data[$i]{foto4}\" WIDTH=\"166\"  BORDER=\"0\">";
}
print <<END_OF_TEXT;
    <td>
</tr>
END_OF_TEXT

if ($data[$i]{pr}  eq "1") {
print<<"END_OF_TEXT";
<TR><TD COLSPAN="2">
$font_1
<BR>
<B>Rentabilidad ;</B>
<BR>
<CENTER>
<TABLE WIDTH="550" CELLSPACING="0" CELLPADDING="0" BORDER="0">
<TR>
<TD WIDTH="50%">
<DIV ALIGN="justify">
<FONT FACE="arial" SIZE=-1>
<BR>
Propiedad con Rentabilidad : Si<BR>
Régimen de Propiedad : $data[$i]{pr_regimen} <BR>
Rentabilidad Anual : $data[$i]{pr_rent} <BR>
<BR>
</TD>
<TD WIDTH="50%">
<DIV ALIGN="justify">
<FONT FACE="arial" SIZE=-1>
<BR>
Contrato actual de Arrendamiento : $data[$i]{pr_cont_arr} <BR>
Vigencia del Contrato : $data[$i]{pr_vigencia}<BR>
Nombre del Arrendatario : $data[$i]{pr_nombre_arr}<BR>
</DIV>
</TD>
</TR>
</TABLE>
</CENTER>
</TD></TR>
END_OF_TEXT
}

print<<"END_OF_TEXT";
<TR>
<TD COLSPAN="2">
$font_1
<BR>
<DIV ALIGN="justify">
<B class="text-danger">Detalles :</B>
END_OF_TEXT
if ($data[$i]{foto2} ne "") {
print "<a class=\"btn btn-default btn-xs\" href=\"javascript:self.makeNewWindow('imprimir_fotos.cgi?id=$data[$i]{id_propiedad}&ref_propiedad=$data[$i]{ref_propiedad}&id_usuario=$id_usuario&propiedades=$propiedades&web=$web&id_oficina=$oficina[5]')\" role=\"button\">\n";
print "Ver más Fotos\n";
print "</a> <br>\n";
}
print "<IMG SRC=\"$imgurl/blank.gif\" WIDTH=\"5\" HEIGHT=\"1\" BORDER=\"0\">\n";
if ( $data[$i]{youtube} ne "") {
print " <a class=\"btn btn-default btn-xs\" href=\"javascript:self.makeNewWindow('$data[$i]{youtube}')\" role=\"button\">\n";
print "Ver Video\n";
print "</a>\n";
}
print<<"END_OF_TEXT";
$data[$i]{descripcion}<BR>
$data[$i]{detalle}<BR><BR>
</DIV>
</TD>
</TR>
</TABLE>
END_OF_TEXT

#if ($web ne "1") {
#print "<CENTER>$d_dir_propiedad\n";
#if ($d_calle1 ne "") {print " entre $d_calle1 \n";}
#if ($d_calle2 ne "") {print " y $d_calle2\n";}
#}
if ($mapa == 1) {
print <<END_OF_TEXT;
<BR>
<BR>
END_OF_TEXT

print <<END_OF_TEXT;
<TABLE WIDTH="600" CELLSPACING="5" CELLPADDING="0" BORDER="0">
<tr>
<td valign="top">
  <div class="row" ALIGN="justify">
      <div class="col-sm-12 col-md-12">
      <B>Localización del Inmueble :</B><BR>
      <BR>$col_propiedad<BR>$data[$i]{cp} $data[$i]{municipio}, $data[$i]{estado}
      </div>
  </div>
</td>
<td valign="top">
  <div class="row" >
        <div class="col-sm-12 col-md-12">
END_OF_TEXT

if ($data[$i]{latitud} ne "" && $data[$i]{longitud} ne "") {
print "     <div id=\"map-canvas\"></div>\n";
}
else {print " <img src=\"$imgurl/no_mapa.jpg\" class=\"img-responsive\">\n";}
print<<"END_OF_TEXT";
  </div>
  </div>
</td>
</tr>
</TABLE>
END_OF_TEXT
}#If de mapa
else{
print <<END_OF_TEXT;
<TABLE WIDTH="600" CELLSPACING="5" CELLPADDING="0" BORDER="0">
<tr>
<td valign="top">
  <div class="row" ALIGN="justify">
      <div class="col-sm-12 col-md-12">
      <B>Localización del Inmueble :</B><BR>
      <BR>$col_propiedad<BR>$data[$i]{cp} $data[$i]{municipio}, $data[$i]{estado}
      </div>
  </div>
</td>
</tr>
</TABLE>
END_OF_TEXT
}
print<<END_OF_TEXT;
<TR><TD COLSPAN="2" ALIGN="center" VALIGN="top">
$font_1
<HR WIDTH="600" COLOR="#008000">
Para mayores informes contacte a nuestro Asesor :<BR>

END_OF_TEXT

if ($nombre_asesor ne ""){
print "$nombre_asesor<BR>\n";
print "$tel_asesor<BR>\n";
}
else {
print "Gerencia de Ventas<BR>\n";
print "$oficina[10]<BR>\n";

# open(DATA,"$enviar_email_a");
# $i = <DATA>;
# close(DATA);
# ($destinatario,$asunto) = split(/\|/, $i);
@paginas = &Paginas($oficina[5]);
$destinatario = $paginas[1];
$asunto = $paginas[2];

print "Email : $destinatario<BR>\n";
}

print <<END_OF_TEXT;
</TD></TR>
</TABLE>
<BR>
END_OF_TEXT
}# Termina if

}# Termina foreach

print <<END_OF_TEXT;

</TD>
</TR>
</TABLE>

</center>

</BODY>
</HTML>
END_OF_TEXT

exit;

}# Termina sub Presentar_Forma_Impresion